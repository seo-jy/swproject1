package com.example.calling;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    private EditText editTextNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextNumber = findViewById(R.id.editTextNumber);
    }

    public void buttonCallClicked(View view) {
        String text = editTextNumber.getText().toString().trim();
        Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:112"));
        startActivity(intent);

    }
    public void buttonNumberClicked(View view) {
        String text = editTextNumber.getText().toString();
        String num = ((Button)view).getText().toString();

       text += num;

       editTextNumber.setText(text);
    }
    public void buttonDelClicked(View view) {
        String text = editTextNumber.getText().toString();
        if (text.length() > 0) {
            text = text.substring(0, text.length() - 1);
            editTextNumber.setText(text);
        }
    }
    public void buttonClearClicked(View view) {
        editTextNumber.setText("");
    }
}